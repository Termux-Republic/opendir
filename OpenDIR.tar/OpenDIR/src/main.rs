use chrono::{DateTime, Local};
use colored::*;
use std::fs;
use std::path::{Path, PathBuf};

const VERSION: &str = "0.1.1";

struct Args {
    path: PathBuf,
    wide: bool,
    paginate: bool,
    recursive: bool,
    show_hidden: bool,
    sort_by: SortBy,
}

#[derive(PartialEq)]
enum SortBy {
    Name,
    Size,
    Date,
    Extension,
}

fn print_help() {
    println!("{}", "OpenDIR — MS-DOS dir, modernized for Rust-supporting systems".bold().cyan());
    println!();
    println!("{}", "USAGE:".yellow().bold());
    println!("  opendir [PATH] [FLAGS]");
    println!();
    println!("{}", "FLAGS:".yellow().bold());
    println!("  {}    Wide list format", "/W".green());
    println!("  {}    Pause after each screen", "/P".green());
    println!("  {}    Recurse into subdirectories", "/S".green());
    println!("  {}    Show hidden files (dotfiles)", "/A".green());
    println!("  {}  Sort by: N=name, S=size, D=date, E=ext", "/O:<key>".green());
    println!("  {}    Show this help", "/H".green());
    println!("  {}    Show version", "/V".green());
    println!();
    println!("{}", "EXAMPLES:".yellow().bold());
    println!("  opendir");
    println!("  opendir /home/user /S /A");
    println!("  opendir . /W /O:S");
}

fn print_version() {
    println!("OpenDIR v{}", VERSION.bold().cyan());
    println!("A faithful MS-DOS dir recreation for Rust-supporting systems");
    println!("https://github.com/TermuxRepublic/opendir");
}

fn parse_args() -> Result<Args, String> {
    let raw: Vec<String> = std::env::args().skip(1).collect();

    let mut path = PathBuf::from(".");
    let mut wide = false;
    let mut paginate = false;
    let mut recursive = false;
    let mut show_hidden = false;
    let mut sort_by = SortBy::Name;

    for arg in &raw {
        let upper = arg.to_uppercase();
        match upper.as_str() {
            "/H" | "--HELP" | "-H" => {
                print_help();
                std::process::exit(0);
            }
            "/V" | "--VERSION" | "-V" => {
                print_version();
                std::process::exit(0);
            }
            "/W" => wide = true,
            "/P" => paginate = true,
            "/S" => recursive = true,
            "/A" => show_hidden = true,
            s if s.starts_with("/O:") => {
                sort_by = match &s[3..] {
                    "S" => SortBy::Size,
                    "D" => SortBy::Date,
                    "E" => SortBy::Extension,
                    _ => SortBy::Name,
                };
            }
            _ => {
                if !arg.starts_with('/') || Path::new(arg).exists() {
                    path = PathBuf::from(arg);
                } else {
                    return Err(format!("Unknown flag: {}", arg));
                }
            }
        }
    }

    Ok(Args { path, wide, paginate, recursive, show_hidden, sort_by })
}

struct DirEntry {
    name: String,
    is_dir: bool,
    size: u64,
    modified: DateTime<Local>,
    is_hidden: bool,
    extension: String,
}

fn read_dir_entries(path: &Path, show_hidden: bool) -> Vec<DirEntry> {
    let mut entries = Vec::new();

    let read = match fs::read_dir(path) {
        Ok(r) => r,
        Err(e) => {
            eprintln!("{} {}", "Error:".red().bold(), e);
            return entries;
        }
    };

    for entry in read.flatten() {
        let name = entry.file_name().to_string_lossy().to_string();
        let is_hidden = name.starts_with('.');

        if is_hidden && !show_hidden {
            continue;
        }

        let meta = match entry.metadata() {
            Ok(m) => m,
            Err(_) => continue,
        };

        let is_dir = meta.is_dir();
        let size = if is_dir { 0 } else { meta.len() };
        let modified: DateTime<Local> = meta
            .modified()
            .map(DateTime::from)
            .unwrap_or_else(|_| Local::now());

        let extension = if is_dir {
            String::new()
        } else {
            Path::new(&name)
                .extension()
                .map(|e| e.to_string_lossy().to_uppercase().to_string())
                .unwrap_or_default()
        };

        entries.push(DirEntry { name, is_dir, size, modified, is_hidden, extension });
    }

    entries
}

fn sort_entries(entries: &mut Vec<DirEntry>, sort_by: &SortBy) {
    entries.sort_by(|a, b| {
        if a.is_dir != b.is_dir {
            return b.is_dir.cmp(&a.is_dir);
        }
        match sort_by {
            SortBy::Name => a.name.to_lowercase().cmp(&b.name.to_lowercase()),
            SortBy::Size => a.size.cmp(&b.size),
            SortBy::Date => a.modified.cmp(&b.modified),
            SortBy::Extension => a.extension.cmp(&b.extension),
        }
    });
}

fn format_size(size: u64) -> String {
    if size >= 1_073_741_824 {
        format!("{:.1} GiB", size as f64 / 1_073_741_824.0)
    } else if size >= 1_048_576 {
        format!("{:.1} MiB", size as f64 / 1_048_576.0)
    } else if size >= 1_024 {
        format!("{:.1} KiB", size as f64 / 1_024.0)
    } else {
        format!("{} B", size)
    }
}

fn get_free_space(path: &Path) -> Option<u64> {
    #[cfg(unix)]
    {
        use std::ffi::CString;
        let path_str = path.canonicalize().ok()?;
        let cstr = CString::new(path_str.to_string_lossy().as_bytes()).ok()?;
        unsafe {
            let mut stat: libc::statvfs = std::mem::zeroed();
            if libc::statvfs(cstr.as_ptr(), &mut stat) == 0 {
                return Some(stat.f_bavail * stat.f_frsize);
            }
        }
    }
    None
}

fn get_hostname() -> String {
    fs::read_to_string("/etc/hostname")
        .map(|s| s.trim().to_string())
        .unwrap_or_else(|_| "LINUX".to_string())
}

fn print_header(path: &Path) {
    let hostname = get_hostname();
    let abs = path.canonicalize().unwrap_or_else(|_| path.to_path_buf());

    println!();
    println!(" {} {}", "Volume:".dimmed(), hostname.bold().cyan());
    println!(" {} {}", "Directory of".dimmed(), abs.display().to_string().bold().white());
    println!();
    println!(" {:<24} {:>10}  {}", "Date Modified".dimmed(), "Size".dimmed(), "Name".dimmed());
    println!(" {}", "─".repeat(52).dimmed());
}

fn colorize_name(entry: &DirEntry) -> String {
    if entry.is_dir {
        return format!("{}/", entry.name).blue().bold().to_string();
    }
    if entry.is_hidden {
        return entry.name.dimmed().to_string();
    }
    match entry.extension.as_str() {
        "RS" | "C" | "CPP" | "H" | "PY" | "JS" | "TS" | "GO" | "ZIG" => entry.name.green().to_string(),
        "SH" | "BASH" | "ZSH" | "FISH" => entry.name.yellow().to_string(),
        "MD" | "TXT" | "README" | "LICENSE" => entry.name.white().to_string(),
        "TOML" | "JSON" | "YAML" | "YML" | "XML" | "INI" | "CONF" => entry.name.magenta().to_string(),
        "EXE" | "OUT" => entry.name.red().bold().to_string(),
        "ZIP" | "TAR" | "GZ" | "XZ" | "ZST" | "BZ2" | "7Z" => entry.name.yellow().bold().to_string(),
        "PNG" | "JPG" | "JPEG" | "GIF" | "WEBP" | "SVG" => entry.name.bright_magenta().to_string(),
        "MP3" | "OGG" | "FLAC" | "WAV" | "OPUS" => entry.name.bright_cyan().to_string(),
        "MP4" | "MKV" | "AVI" | "WEBM" => entry.name.bright_blue().to_string(),
        _ => entry.name.normal().to_string(),
    }
}

fn print_entry_long(entry: &DirEntry) {
    let date_str = entry.modified.format("%m/%d/%Y  %I:%M %p").to_string();

    let size_str = if entry.is_dir {
        "<DIR>".blue().bold().to_string()
    } else {
        format_size(entry.size).normal().to_string()
    };

    println!(" {:<24} {:>10}  {}", date_str.dimmed(), size_str, colorize_name(entry));
}

fn term_width() -> usize {
    if let Ok(val) = std::env::var("COLUMNS") {
        if let Ok(w) = val.parse::<usize>() {
            return w;
        }
    }
    if let Ok(out) = std::process::Command::new("tput").arg("cols").output() {
        if let Ok(s) = std::str::from_utf8(&out.stdout) {
            if let Ok(w) = s.trim().parse::<usize>() {
                return w;
            }
        }
    }
    80
}

fn print_wide(entries: &[DirEntry]) {
    let term_width = term_width();
    let col_width = 20usize;
    let cols = (term_width / col_width).max(1);

    let mut col = 0;
    for entry in entries {
        let name = if entry.is_dir {
            format!("[{}]", entry.name).blue().bold().to_string()
        } else {
            entry.name.clone()
        };
        print!("{:<width$}", name, width = col_width);
        col += 1;
        if col >= cols {
            println!();
            col = 0;
        }
    }
    if col != 0 {
        println!();
    }
}

fn print_footer(entries: &[DirEntry], path: &Path) {
    let file_count = entries.iter().filter(|e| !e.is_dir).count();
    let dir_count = entries.iter().filter(|e| e.is_dir).count();
    let total_size: u64 = entries.iter().map(|e| e.size).sum();

    println!(" {}", "─".repeat(52).dimmed());
    println!("         {} file(s)    {}", file_count.to_string().bold(), format_size(total_size).bold());
    println!("         {} dir(s)", dir_count.to_string().bold());

    if let Some(free) = get_free_space(path) {
        println!("         {} free", format_size(free).green().bold());
    }
    println!();
}

fn paginate_prompt() {
    use std::io::{self, Write};
    print!("{}", " -- More -- Press ENTER to continue --".on_black().white());
    io::stdout().flush().ok();
    let mut buf = String::new();
    io::stdin().read_line(&mut buf).ok();
    // clear the prompt line
    print!("\r{}\r", " ".repeat(50));
}

fn list_dir(path: &Path, args: &Args, depth: usize) {
    let mut entries = read_dir_entries(path, args.show_hidden);
    sort_entries(&mut entries, &args.sort_by);

    print_header(path);

    if args.wide {
        print_wide(&entries);
    } else {
        let term_h = if args.paginate {
            // rough terminal height
            if let Ok(out) = std::process::Command::new("tput").arg("lines").output() {
                std::str::from_utf8(&out.stdout)
                    .ok()
                    .and_then(|s| s.trim().parse::<usize>().ok())
                    .unwrap_or(24)
            } else { 24 }
        } else { usize::MAX };

        let mut line_count = 4; // header lines
        for entry in &entries {
            print_entry_long(entry);
            line_count += 1;
            if args.paginate && line_count >= term_h - 2 {
                paginate_prompt();
                line_count = 0;
            }
        }
    }

    print_footer(&entries, path);

    if args.recursive {
        for entry in &entries {
            if entry.is_dir && entry.name != "." && entry.name != ".." {
                let sub = path.join(&entry.name);
                list_dir(&sub, args, depth + 1);
            }
        }
    }
}

fn main() {
    let args = match parse_args() {
        Ok(a) => a,
        Err(e) => {
            eprintln!("{} {}", "Error:".red().bold(), e);
            eprintln!("Run {} for usage.", "opendir /H".cyan());
            std::process::exit(1);
        }
    };

    if !args.path.exists() {
        eprintln!("{} path not found: {}", "Error:".red().bold(), args.path.display());
        std::process::exit(1);
    }

    list_dir(&args.path, &args, 0);
}
